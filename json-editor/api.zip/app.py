import json
import os
import sys
import time
import uuid
import traceback
from datetime import datetime, timezone
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import boto3
from boto3.dynamodb.conditions import Key

JSON_BUCKET = os.environ.get("JSON_BUCKET", "")
SNAPSHOT_BUCKET = os.environ.get("SNAPSHOT_BUCKET", "")
SCHEMA_PREFIX = os.environ.get("SCHEMA_PREFIX", "_schemas/")
CHANGE_TABLE = os.environ.get("CHANGE_TABLE", "")
AUDIT_TABLE = os.environ.get("AUDIT_TABLE", "")
NOTIFY_FROM = os.environ.get("NOTIFY_FROM", "noreply-liturgicalbooks@theotokoseb.com")
NOTIFY_REPLY_TO = os.environ.get("NOTIFY_REPLY_TO", "liturgicalbooks@saint-mary.net")
NOTIFY_REGION = os.environ.get("NOTIFY_REGION", "us-east-2")
NOTIFY_ADMINS = os.environ.get("NOTIFY_ADMINS", "")
REPORTS_EMAIL_TO = os.environ.get("REPORTS_EMAIL_TO", NOTIFY_REPLY_TO)
REPORTS_PREFIX = os.environ.get("REPORTS_PREFIX", "reports/")
REPORTS_MAX_UPLOAD_BYTES = int(os.environ.get("REPORTS_MAX_UPLOAD_BYTES", "41943040"))
REPORTS_MAX_EMAIL_BYTES = int(os.environ.get("REPORTS_MAX_EMAIL_BYTES", "9437184"))

s3 = boto3.client("s3")
ddb = boto3.resource("dynamodb")
ses = boto3.client("ses", region_name=NOTIFY_REGION)


def response(status, body=None):
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Authorization,Content-Type",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    }
    if body is None:
        return {"statusCode": status, "headers": headers}
    return {"statusCode": status, "headers": headers, "body": json.dumps(body)}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def get_claims(event):
    return (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("jwt", {})
        .get("claims", {})
    )


def get_user(event):
    claims = get_claims(event)
    raw_groups = claims.get("cognito:groups") or []
    if isinstance(raw_groups, str):
        groups = raw_groups.split(",") if raw_groups else []
    else:
        groups = list(raw_groups)
    return {
        "username": claims.get("cognito:username") or claims.get("username"),
        "email": claims.get("email"),
        "groups": groups,
    }


def require_config():
    missing = []
    for key, value in {
        "JSON_BUCKET": JSON_BUCKET,
        "SNAPSHOT_BUCKET": SNAPSHOT_BUCKET,
        "CHANGE_TABLE": CHANGE_TABLE,
        "AUDIT_TABLE": AUDIT_TABLE,
    }.items():
        if not value:
            missing.append(key)
    if missing:
        raise RuntimeError(f"Missing env: {', '.join(missing)}")


def list_files():
    manifest_key = "manifest.json"
    hidden_prefixes = ("bible/",)
    hidden_files = {"images.json"}
    try:
        manifest = s3.get_object(Bucket=JSON_BUCKET, Key=manifest_key)
        data = json.loads(manifest["Body"].read())
        files = data.get("files", [])
        return [
            {
                "path": item.get("path"),
                "size": item.get("size"),
                "hash": item.get("hash"),
            }
            for item in files
            if item.get("path")
            and not item["path"].startswith(hidden_prefixes)
            and item["path"] not in hidden_files
        ]
    except s3.exceptions.NoSuchKey:
        paginator = s3.get_paginator("list_objects_v2")
        entries = []
        for page in paginator.paginate(Bucket=JSON_BUCKET):
            for item in page.get("Contents", []):
                if not item["Key"].endswith(".json"):
                    continue
                if item["Key"] == manifest_key:
                    continue
                if item["Key"].startswith(hidden_prefixes) or item["Key"] in hidden_files:
                    continue
                entries.append({"path": item["Key"], "size": item.get("Size")})
        return entries


def read_json(bucket, key):
    obj = s3.get_object(Bucket=bucket, Key=key)
    return json.loads(obj["Body"].read())


def write_json(bucket, key, data):
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data, indent=2, ensure_ascii=False).encode("utf-8"),
        ContentType="application/json",
    )


def record_audit(path, action, actor, change_id, details=None):
    table = ddb.Table(AUDIT_TABLE)
    table.put_item(
        Item={
            "path": path,
            "timestamp": now_iso(),
            "action": action,
            "actor": actor,
            "changeId": change_id,
            "details": details or {},
        }
    )


def send_notification(to_addresses, subject, body):
    """
    Fire-and-forget SES email. Accepts a single address or a list. If sending fails,
    we log and continue so flows do not break.
    """
    if not to_addresses:
        return
    if isinstance(to_addresses, str):
        to_list = [to_addresses]
    else:
        to_list = list(to_addresses)
    to_list = [addr for addr in to_list if addr]
    if not to_list:
        return
    try:
        ses.send_email(
          Source=NOTIFY_FROM,
          Destination={"ToAddresses": to_list},
          Message={
            "Subject": {"Data": subject, "Charset": "UTF-8"},
            "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
          },
          ReplyToAddresses=[NOTIFY_REPLY_TO],
        )
    except Exception as err:  # pragma: no cover - notification best effort
        print(f"Failed to send notification to {to_address}: {err}")


def sanitize_filename(filename):
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in filename)
    return safe or "attachment"


def get_report_prefix():
    return REPORTS_PREFIX if REPORTS_PREFIX.endswith("/") else f"{REPORTS_PREFIX}/"


def presign_upload(bucket, key, content_type):
    return s3.generate_presigned_url(
        "put_object",
        Params={"Bucket": bucket, "Key": key, "ContentType": content_type},
        ExpiresIn=3600,
    )


def presign_download(bucket, key):
    return s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=60 * 60 * 24 * 7,
    )


def send_report_email(subject, body, attachments, reply_to=None):
    msg = MIMEMultipart()
    msg["Subject"] = subject
    msg["From"] = NOTIFY_FROM
    msg["To"] = REPORTS_EMAIL_TO
    msg["Reply-To"] = reply_to or NOTIFY_REPLY_TO
    msg.attach(MIMEText(body, "plain", "utf-8"))

    total_bytes = 0
    for attachment in attachments:
        if not attachment.get("key"):
            continue
        size = attachment.get("size") or 0
        if size <= 0:
            continue
        if total_bytes + size > REPORTS_MAX_EMAIL_BYTES:
            continue
        try:
            obj = s3.get_object(Bucket=SNAPSHOT_BUCKET, Key=attachment["key"])
        except Exception as err:  # pragma: no cover - defensive
            print(f"Failed to load attachment {attachment['key']}: {err}")
            continue
        payload = obj["Body"].read()
        content_type = attachment.get("contentType") or "application/octet-stream"
        if "/" in content_type:
            main_type, sub_type = content_type.split("/", 1)
        else:
            main_type, sub_type = "application", "octet-stream"
        part = MIMEBase(main_type, sub_type)
        part.set_payload(payload)
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f'attachment; filename="{sanitize_filename(attachment.get("name") or "attachment")}"',
        )
        msg.attach(part)
        total_bytes += size

    ses.send_raw_email(
        Source=NOTIFY_FROM,
        Destinations=[REPORTS_EMAIL_TO],
        RawMessage={"Data": msg.as_string()},
    )


def handle_list_files(event):
    return response(200, {"files": list_files()})


def handle_get_file(event, key):
    data = read_json(JSON_BUCKET, key)
    return response(200, data)


def handle_get_schema(event, key):
    if key.endswith(".json"):
        schema_key = f"{SCHEMA_PREFIX}{key[:-5]}.schema.json"
    else:
        schema_key = f"{SCHEMA_PREFIX}{key}.schema.json"
    data = read_json(JSON_BUCKET, schema_key)
    return response(200, data)


def handle_submit_change(event):
    payload = json.loads(event.get("body") or "{}")
    path = payload.get("path")
    summary = payload.get("summary", "")
    data = payload.get("data")
    if not path:
        return response(400, {"message": "Missing path"})
    if data is None:
        return response(400, {"message": "Missing data"})

    user = get_user(event)
    change_id = str(uuid.uuid4())
    created_at = now_iso()

    pending_key = f"pending/{change_id}.json"
    write_json(SNAPSHOT_BUCKET, pending_key, {"path": path, "data": data})

    table = ddb.Table(CHANGE_TABLE)
    table.put_item(
        Item={
            "id": change_id,
            "path": path,
            "summary": summary,
            "status": "pending",
            "createdAt": created_at,
            "requestedBy": user.get("username"),
            "requestedByEmail": user.get("email"),
            "pendingKey": pending_key,
        }
    )

    record_audit(path, "submitted", user.get("username"), change_id, {"summary": summary})

    admin_recipients = [addr.strip() for addr in NOTIFY_ADMINS.split(",") if addr.strip()]
    if admin_recipients:
        send_notification(
            admin_recipients,
            subject=f"[LiturgicalBooks] New change submitted: {path}",
            body=(
                f"A new change was submitted.\n\n"
                f"File: {path}\n"
                f"Summary: {summary or 'No summary provided'}\n"
                f"Requested by: {user.get('username')}\n"
                f"Requestor email: {user.get('email') or 'Unknown'}\n"
                f"Change ID: {change_id}\n"
            ),
        )
    return response(201, {"id": change_id})


def handle_list_changes(event):
    params = event.get("queryStringParameters") or {}
    status = params.get("status", "pending")

    table = ddb.Table(CHANGE_TABLE)
    index = "StatusIndex"
    items = table.query(
        IndexName=index,
        KeyConditionExpression=Key("status").eq(status),
    ).get("Items", [])
    return response(200, {"changes": items})


def handle_get_change(event, change_id):
    table = ddb.Table(CHANGE_TABLE)
    item = table.get_item(Key={"id": change_id}).get("Item")
    if not item:
        return response(404, {"message": "Change not found"})

    result = dict(item)
    pending_key = item.get("pendingKey")
    path = item.get("path")

    pending_data = None
    pending_error = None
    pending_size = None
    if pending_key:
        try:
            pending_snapshot = read_json(SNAPSHOT_BUCKET, pending_key)
            pending_data = pending_snapshot.get("data")
            pending_size = len(json.dumps(pending_snapshot).encode("utf-8"))
        except Exception as err:  # pragma: no cover - safety net for s3 read failures
            pending_error = str(err)

    current_data = None
    current_error = None
    current_size = None
    if path:
        try:
            current_data = read_json(JSON_BUCKET, path)
            current_size = len(json.dumps(current_data).encode("utf-8"))
        except Exception as err:  # pragma: no cover - safety net for s3 read failures
            current_error = str(err)

    def truncate_value(val, max_len=500):
        if isinstance(val, str) and len(val) > max_len:
            return val[: max_len - 3] + "..."
        return val

    diff = []
    diff_limit = 500
    sentinel = object()

    def path_to_str(parts):
        out = []
        for p in parts:
            if isinstance(p, int):
                out.append(f"[{p}]")
            else:
                if out:
                    out.append(".")
                out.append(str(p))
        return "".join(out) or "<root>"

    def walk(a, b, path):
        if len(diff) >= diff_limit:
            return
        if a is sentinel:
            diff.append({"path": path_to_str(path), "before": None, "after": truncate_value(b)})
            return
        if b is sentinel:
            diff.append({"path": path_to_str(path), "before": truncate_value(a), "after": None})
            return
        if isinstance(a, dict) and isinstance(b, dict):
            keys = set(a.keys()) | set(b.keys())
            for k in keys:
                walk(a.get(k, sentinel), b.get(k, sentinel), path + [k])
        elif isinstance(a, list) and isinstance(b, list):
            max_len = max(len(a), len(b))
            for i in range(max_len):
                av = a[i] if i < len(a) else sentinel
                bv = b[i] if i < len(b) else sentinel
                walk(av, bv, path + [i])
        else:
            if a != b:
                diff.append(
                    {
                        "path": path_to_str(path),
                        "before": truncate_value(a),
                        "after": truncate_value(b),
                    }
                )

    if pending_data is not None and current_data is not None:
        walk(current_data, pending_data, [])
    elif pending_data is not None and current_data is None:
        walk(sentinel, pending_data, [])
    elif pending_data is None and current_data is not None:
        walk(current_data, sentinel, [])

    # Do not embed full data to avoid >6MB Lambda response limit; expose sizes, presigned URLs, and a summarized diff.
    result["pendingData"] = None
    result["currentData"] = None
    result["pendingSize"] = pending_size
    result["currentSize"] = current_size
    result["diff"] = diff
    result["diffTruncated"] = len(diff) >= diff_limit

    if pending_key:
        result["pendingUrl"] = presign_download(SNAPSHOT_BUCKET, pending_key)
    if path:
        result["currentUrl"] = presign_download(JSON_BUCKET, path)
    if pending_error:
        result["pendingError"] = pending_error
    if current_error:
        result["currentError"] = current_error

    return response(200, {"change": result, "dataEmbedded": False})


def handle_approve_change(event, change_id):
    user = get_user(event)
    table = ddb.Table(CHANGE_TABLE)
    item = table.get_item(Key={"id": change_id}).get("Item")
    if not item:
        return response(404, {"message": "Change not found"})
    if item.get("status") != "pending":
        return response(400, {"message": "Change is not pending"})

    pending_key = item.get("pendingKey")
    pending = read_json(SNAPSHOT_BUCKET, pending_key)
    path = pending.get("path")
    data = pending.get("data")

    write_json(JSON_BUCKET, path, data)

    snapshot_key = f"snapshots/{path}/{int(time.time())}-{change_id}.json"
    write_json(SNAPSHOT_BUCKET, snapshot_key, data)

    table.update_item(
        Key={"id": change_id},
        UpdateExpression="SET #status = :status, approvedAt = :approvedAt, approvedBy = :approvedBy",
        ExpressionAttributeNames={"#status": "status"},
        ExpressionAttributeValues={
            ":status": "approved",
            ":approvedAt": now_iso(),
            ":approvedBy": user.get("username"),
        },
    )

    record_audit(path, "approved", user.get("username"), change_id)

    send_notification(
        item.get("requestedByEmail"),
        subject=f"[LiturgicalBooks] Change approved: {path}",
        body=(
            f"Your change request has been approved.\n\n"
            f"File: {path}\n"
            f"Summary: {item.get('summary') or 'No summary provided'}\n"
            f"Approved by: {user.get('username')}\n"
            f"Change ID: {change_id}\n"
        ),
    )
    return response(200, {"message": "Approved"})


def handle_reject_change(event, change_id):
    payload = json.loads(event.get("body") or "{}")
    reason = payload.get("reason", "")
    user = get_user(event)

    table = ddb.Table(CHANGE_TABLE)
    item = table.get_item(Key={"id": change_id}).get("Item")
    if not item:
        return response(404, {"message": "Change not found"})
    if item.get("status") != "pending":
        return response(400, {"message": "Change is not pending"})

    table.update_item(
        Key={"id": change_id},
        UpdateExpression="SET #status = :status, rejectedAt = :rejectedAt, rejectedBy = :rejectedBy, rejectionReason = :reason",
        ExpressionAttributeNames={"#status": "status"},
        ExpressionAttributeValues={
            ":status": "rejected",
            ":rejectedAt": now_iso(),
            ":rejectedBy": user.get("username"),
            ":reason": reason,
        },
    )

    record_audit(item.get("path"), "rejected", user.get("username"), change_id, {"reason": reason})

    send_notification(
        item.get("requestedByEmail"),
        subject=f"[LiturgicalBooks] Change rejected: {item.get('path')}",
        body=(
            f"Your change request has been rejected.\n\n"
            f"File: {item.get('path')}\n"
            f"Summary: {item.get('summary') or 'No summary provided'}\n"
            f"Rejected by: {user.get('username')}\n"
            f"Reason: {reason or 'No reason provided'}\n"
            f"Change ID: {change_id}\n"
        ),
    )
    return response(200, {"message": "Rejected"})


def handle_report_uploads(event):
    payload = json.loads(event.get("body") or "{}")
    files = payload.get("files") or []
    report_id = payload.get("reportId") or str(uuid.uuid4())
    prefix = get_report_prefix()

    uploads = []
    for entry in files:
        name = entry.get("name") or "attachment"
        content_type = entry.get("contentType") or "application/octet-stream"
        size = entry.get("size") or 0
        if size and size > REPORTS_MAX_UPLOAD_BYTES:
            return response(400, {"message": f"Attachment too large: {name}"})
        safe_name = sanitize_filename(name)
        key = f"{prefix}{report_id}/attachments/{uuid.uuid4()}-{safe_name}"
        uploads.append(
            {
                "name": name,
                "key": key,
                "contentType": content_type,
                "uploadUrl": presign_upload(SNAPSHOT_BUCKET, key, content_type),
            }
        )
    return response(200, {"reportId": report_id, "uploads": uploads})


def handle_submit_report(event):
    payload = json.loads(event.get("body") or "{}")
    report_id = payload.get("reportId") or str(uuid.uuid4())
    issue_type = payload.get("issueType") or ""
    summary = payload.get("summary") or ""
    details = payload.get("details") or ""
    if not issue_type:
        return response(400, {"message": "Missing issueType"})
    if not (summary or details):
        return response(400, {"message": "Missing summary or details"})

    prefix = get_report_prefix()
    report_key = f"{prefix}{report_id}/report.json"
    report = dict(payload)
    report["reportId"] = report_id
    report.setdefault("createdAt", now_iso())
    write_json(SNAPSHOT_BUCKET, report_key, report)

    attachments = payload.get("attachments") or []
    attachment_lines = []
    download_links = []
    total_attachment_bytes = 0
    for attachment in attachments:
        name = attachment.get("name") or "attachment"
        size = attachment.get("size") or 0
        total_attachment_bytes += size
        attachment_lines.append(f"- {name} ({size} bytes)")
        if attachment.get("key"):
            download_links.append(
                f"{name}: {presign_download(SNAPSHOT_BUCKET, attachment['key'])}"
            )

    context = payload.get("context") or {}
    body_lines = [
        "A new issue report was submitted.",
        "",
        f"Type: {issue_type}",
        f"Summary: {summary or 'N/A'}",
        f"Details: {details or 'N/A'}",
        f"Expected: {payload.get('expected') or 'N/A'}",
        f"Actual: {payload.get('actual') or 'N/A'}",
        "",
        f"Reporter name: {payload.get('reporterName') or 'N/A'}",
        f"Reporter email: {payload.get('reporterEmail') or 'N/A'}",
        "",
        f"Context screen: {context.get('screenName') or 'N/A'}",
        f"Context table title: {context.get('tableTitle') or 'N/A'}",
        "",
        f"App version: {payload.get('appVersion') or 'N/A'}",
        f"Platform: {payload.get('platform') or 'N/A'}",
        f"Platform version: {payload.get('platformVersion') or 'N/A'}",
        "",
        f"Report ID: {report_id}",
    ]
    if attachment_lines:
        body_lines.extend(["", "Attachments:", *attachment_lines])
    if download_links:
        body_lines.extend(["", "Attachment links (7 days):", *download_links])
    if attachments and total_attachment_bytes > REPORTS_MAX_EMAIL_BYTES:
        body_lines.extend(
            [
                "",
                "Note: Some attachments were too large to include in the email.",
            ]
        )

    subject = f"[LiturgicalBooks] {issue_type} report"
    reply_to = payload.get("reporterEmail") or NOTIFY_REPLY_TO
    send_report_email(subject, "\n".join(body_lines), attachments, reply_to=reply_to)
    return response(201, {"reportId": report_id})


def handler(event, context):
    try:
        if event.get("httpMethod") == "OPTIONS":
            return response(204)

        require_config()

        route_key = event.get("routeKey") or ""
        raw_path = event.get("rawPath") or event.get("path") or ""

        if route_key.startswith("GET /files") and raw_path == "/files":
            return handle_list_files(event)

        if raw_path.startswith("/files/") and route_key.startswith("GET /files"):
            key = raw_path.replace("/files/", "", 1)
            return handle_get_file(event, key)

        if raw_path.startswith("/schemas/") and route_key.startswith("GET /schemas"):
            key = raw_path.replace("/schemas/", "", 1)
            return handle_get_schema(event, key)

        if route_key == "POST /changes":
            return handle_submit_change(event)

        if route_key.startswith("GET /changes") and raw_path != "/changes":
            change_id = raw_path.split("/")[-1]
            return handle_get_change(event, change_id)

        if route_key.startswith("GET /changes"):
            return handle_list_changes(event)

        if raw_path.endswith("/approve"):
            change_id = raw_path.split("/")[-2]
            return handle_approve_change(event, change_id)

        if raw_path.endswith("/reject"):
            change_id = raw_path.split("/")[-2]
            return handle_reject_change(event, change_id)

        if route_key == "POST /reports/uploads":
            return handle_report_uploads(event)

        if route_key == "POST /reports":
            return handle_submit_report(event)

        return response(404, {"message": "Not found"})
    except Exception as err:  # surface silent failures
        print(
            f"ERROR handling {event.get('httpMethod')} {event.get('path') or event.get('rawPath')}: {err}",
            file=sys.stderr,
            flush=True,
        )
        print(traceback.format_exc(), file=sys.stderr, flush=True)
        return response(500, {"message": "Internal error", "error": str(err)})
